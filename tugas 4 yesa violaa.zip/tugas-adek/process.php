<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $nim = trim($_POST['nim']);
    $prodi = trim($_POST['prodi']);
    $fakultas = trim($_POST['fakultas']);
    $file = $_FILES['fileInput'];

    $errors = [];
    
    // Validasi teks
    $inputs = [
        'Nama' => $nama,
        'NIM' => $nim,
        'Program Studi' => $prodi,
        'Fakultas' => $fakultas,
    ];

    foreach ($inputs as $key => $value) {
        if (strlen($value) < 1 || strlen($value) > 100) {
            $errors[] = "$key harus memiliki panjang antara 5 hingga 100 karakter.";
        }
    }

    // Validasi file
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        $errors[] = "File harus diupload.";
    } else {
        $allowedTypes = ['text/plain'];
        if (!in_array($file['type'], $allowedTypes)) {
            $errors[] = "File harus berupa teks (.txt).";
        }
        if ($file['size'] > 1024 * 1024) { // 1MB
            $errors[] = "Ukuran file tidak boleh lebih dari 1MB.";
        }
    }

    if (!empty($errors)) {
        echo "<h3>Error:</h3><ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
        echo '<a href="form.php">Kembali ke form</a>';
        exit;
    }

    // Membaca isi file
    $fileContent = file_get_contents($file['tmp_name']);
    $fileLines = explode(PHP_EOL, $fileContent);

    // Mendapatkan info user-agent
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Menyimpan data di session
    session_start();
    $_SESSION['inputs'] = $inputs;
    $_SESSION['fileContent'] = $fileLines;
    $_SESSION['userAgent'] = $userAgent;

    header('Location: result.php');
    exit;
}
?>
