<?php
session_start();

if (!isset($_SESSION['inputs']) || !isset($_SESSION['fileContent']) || !isset($_SESSION['userAgent'])) {
    header('Location: form.php');
    exit;
}

$inputs = $_SESSION['inputs'];
$fileContent = $_SESSION['fileContent'];
$userAgent = $_SESSION['userAgent'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
    <link rel="stylesheet" href="result.css">
</head>

<body>
    <div class="section">
        <h1>Hasil Form</h1>
        <table border="1">
            <tr>
                <th>Field</th>
                <th>Value</th>
            </tr>
            <?php foreach ($inputs as $field => $value): ?>
                <tr>
                    <td>
                        <?php echo htmlspecialchars($field); ?>
                    </td>
                    <td>
                        <?php echo htmlspecialchars($value); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td>User-Agent</td>
                <td>
                    <?php echo htmlspecialchars($userAgent); ?>
                </td>
            </tr>
        </table>
    </div>
    <div class="section">
        <h1>Isi File</h1>
        <table border="1">
            <tr>
                <th>Line</th>
                <th>Content</th>
            </tr>
            <?php foreach ($fileContent as $index => $line): ?>
                <tr>
                    <td>
                        <?php echo $index + 1; ?>
                    </td>
                    <td>
                        <?php echo htmlspecialchars($line); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <a href="form.php">Kembali ke form</a>
</body>

</html>