<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="form.css">
    <title>Form Input Data</title>
    <script>
        function validateForm() {
            const nama = document.getElementById('nama');
            const nim = document.getElementById('nim');
            const prodi = document.getElementById('prodi');
            const fakultas = document.getElementById('fakultas');
            const fileInput = document.getElementById('fileInput');

            const textInputs = [nama, nim, prodi, fakultas];

            for (let i = 0; i < textInputs.length; i++) {
                if (textInputs[i].value.trim() === '') {
                    alert(`Field ${textInputs[i].name} harus diisi.`);
                    return false;
                }

                if (textInputs[i].value.length < 1 || textInputs[i].value.length > 100) {
                    alert(`Field ${textInputs[i].name} harus memiliki panjang antara 5 hingga 100 karakter.`);
                    return false;
                }
            }

            if (fileInput.files.length === 0) {
                alert('File harus dipilih.');
                return false;
            }

            const file = fileInput.files[0];
            const allowedTypes = ['text/plain'];
            if (!allowedTypes.includes(file.type)) {
                alert('File harus berupa teks (.txt).');
                return false;
            }

            if (file.size > 1024 * 1024) { // 1MB
                alert('Ukuran file tidak boleh lebih dari 1MB.');
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h1>Form Input Data Mahasiswa</h1>
    <form action="process.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" minlength="1" maxlength="100" required>
        <br><br>

        <label for="nim">NIM:</label><br>
        <input type="text" id="nim" name="nim" minlength="1" maxlength="100" required>
        <br><br>

        <label for="prodi">Program Studi:</label><br>
        <input type="text" id="prodi" name="prodi" minlength="1" maxlength="100" required>
        <br><br>

        <label for="fakultas">Fakultas:</label><br>
        <input type="text" id="fakultas" name="fakultas" minlength="1" maxlength="100" required>
        <br><br>

        <label for="fileInput">Upload File:</label><br>
        <input type="file" id="fileInput" name="fileInput" accept=".txt" required>
        <br><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
